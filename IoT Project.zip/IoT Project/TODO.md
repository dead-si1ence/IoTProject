# Data Cleaning:

1. Renameing Files
1. Renaming columns
1. Droping columns if nessecery
1. Correscting the columns data types
1. Filling null values
1. Making heart rate to numbers

# Generating New Data:

1. Generating multiple files
1. Generating new data 12 months for each patient

#  Choose an algorithm

* XGBoost
* Extra Trees
* Blending

# Tuning

# Show Results